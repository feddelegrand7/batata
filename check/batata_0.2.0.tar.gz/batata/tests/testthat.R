library(testthat)
library(batata)

test_check("batata")
