# batata 0.2.0

# batata 0.1.1

* fixed some bugs related to dates using the lubridate package. 
* I've replaced the fs::file_info() with file.mtime() base R in order to get folders' modified time. 

# batata 0.1.0

* First release on CRAN commit: 39814ee046
